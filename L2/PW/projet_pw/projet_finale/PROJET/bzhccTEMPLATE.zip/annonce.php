<?php
include("inc/top.php");
?>

<!-- debut de la partie contenu -->
<div class="main">
<div class="details">
				  <div class="product-details">				
					<div class="images_3_of_2">
						<div id="container">
						   <div id="products_example">
							<div id="products">
								<div class="slides_container">
									<a href="#" target="_blank"><img src="images/productslide-1.jpg" alt=" " /></a>
								
								</div>
								<ul class="pagination">
									<li><a href="#"><img src="images/thumbnailslide-1.jpg" alt=" " /></a></li>
								
                                
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="desc span_3_of_2">
					<h2>titre de l'annonce</h2>
					<p>texte de l'annonce</p>					
					<div class="price">
						<p>Prix: <span>500 �</span></p>
					</div>
				
            
            
				 <div class="wish-list">
				 	<ul>
				 		<li class="wish"><a href="#">Ajouter � mes favoris</a></li>
				 
				 	</ul>
				 </div>
			</div>
			<div class="clear"></div>
		  </div>

	   
       		
   <div class="content_bottom">
   	<div class="text-h1 top1 btm">
			<h2>Annonces qui pourraient vous int�resser</h2>
	  	</div>
 <div class="div2">
        <div id="mcts1">
			<div class="w3l-img">
        		<img src="images/pic2.png" alt=""/>
			</div>
			<div class="w3l-img">
				<img src="images/pic3.png" alt="" />
			</div>	
			<div class="w3l-img">
				<img src="images/pic1.png" alt="" />
			</div>
			
			<div class="clear"></div>	
        </div>
   		</div>

    	</div>

        </div>
<div class="sidebar">
<div class="s-main">
	<div class="s_hdr">
		<h2>Categories</h2>
	</div>
	<div class="text1-nav">
		<ul>
			<li><a href="">The standard chunk of Lorem gfd</a></li>
			<li><a href="">Duis a augue ac libero euismodf</a></li>
			<li><a href="">The standard chunk of Lorem Ips</a></li>
			<li><a href="">Duis a augue ac libero euismodd</a></li>
			<li><a href="">The standard chunk of Lorem gfd</a></li>
			<li><a href="">Duis a augue ac libero euismodf</a></li>
			<li><a href="">The standard chunk of Lorem Ips</a></li>
			<li><a href="">Duis a augue ac libero euismodd</a></li>
			<li><a href="">The standard chunk of Lorem gfd</a></li>
			<li><a href="">Duis a augue ac libero euismodf</a></li>
			<li><a href="">The standard chunk of Lorem Ips</a></li>
			<li><a href="">Duis a augue ac libero euismodd</a></li>
			<li><a href="">The standard chunk of Lorem Ips</a></li>
			<li><a href="">Duis a augue ac libero euismodd</a></li>
	    </ul>
	</div>
</div>
</div>
<div class="clear"></div>
</div>
<!-- fin de la partie contenu -->
<?php
include("inc/bottom.php");
?>