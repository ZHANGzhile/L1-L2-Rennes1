<?php
include("inc/top.php");
?>
<div class="main">
<div class="page">
	<h2>404</h2>
</div>
<div class="clear"></div>
</div>
<?php
include("inc/bottom.php");
?>