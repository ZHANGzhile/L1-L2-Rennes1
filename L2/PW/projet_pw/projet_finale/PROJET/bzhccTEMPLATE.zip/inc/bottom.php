</div>
<div class="footer-bg">
<div class="wrap">
<div class="footer">
	<div class="f_nav">
		<ul>
			<li><a href="#">A propos</a></li>
			<li><a href="#">Contact</a></li>


		</ul>
	</div>
	<div class="footer1">
		<p>&copy; 2022 BreizhCoinCoin . Tous droits réservés</p>
	</div>
</div>
</div>
</div>
</body>
</html>