<?php
include("inc/top.php");
?>

<!-- debut de la partie contenu -->
<div class="main">
<div class="sidebar">
<div class="s-main">
	<div class="s_hdr">
		<h2>Catégories</h2>
	</div>
	<div class="text1-nav">
		<ul>
			<li><a href="">Jouets</a></li>
			<li><a href="">Jeux</a></li>
			<li><a href="">Livres</a></li>
			<li><a href="">Bijoux</a></li>
			<li><a href="">Voitures</a></li>
			<li><a href="">Locations</a></li>

	    </ul>
	</div>
</div>


</div>

<div class="content">


	<div class="clear"></div>
	<div class="cnt-main">
		<div class="s_btn">
			<ul>
				<li><h2>Bienvenue !</h2></li>
				<li><h3><a href="login.php">Se connecter</a></h3></li>
				<li><h2>Nouveau visiteur ?</h2></li>
				<li><h4><a href="sinscrire.php">S'enregistrer</a></h4></li>
				<div class="clear"></div>
			</ul>
		</div>
	<div class="grid">
	<div class="grid-img">
		<a href="annonce.php"><img src="images/pic1.jpg" alt=""/></a>
	</div>
	<div class="grid-para">
		<h2>Nouveau sur le site</h2>
		<h3>A vendre Joli produit</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
		<div class="btn top">
		<a href="annonce.php">Details&nbsp;<img src="images/marker2.png"></a>
		</div>
	</div>
	<div class="clear"></div>
	</div>
</div>
<div class="cnt-main btm">
	<div class="section group">
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic2.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$21.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic3.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$91.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic8.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$62.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">	
					 <a href="annonce.php"><img src="images/pic4.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$92.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic1.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$12.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic6.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$63.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic5.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$86.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic7.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$61.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					 <a href="annonce.php"><img src="images/pic9.png" alt=""/></a>
					 <a href="annonce.php"><h3>Lorem Ipsum is simply</h3></a>
					 <div class="cart-b">
					<span class="price left"><sup>$22.00</sup><sub></sub></span>
				    <div class="btn top-right right"><a href="annonce.php">Ajouter à mes favoris</a></div>
				    <div class="clear"></div>
				 </div>
				</div>
		
			</div>
</div>
</div>

<div class="clear"></div>
</div>

<!-- fin de la partie contenu -->
<?php
include("inc/bottom.php");
?>
