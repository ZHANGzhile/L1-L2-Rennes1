<?php
include("inc/top.php");
?>

<!-- debut de la partie contenu -->
<div class="main">
     <div class="register">
		  	  <form> 
				 <div class="register-top-grid">
					<h3>Vos informations</h3>
					 <div>
						<span>Pr�nom<label>*</label></span>
						<input type="text"> 
					 </div>
					 <div>
						<span>Nom<label>*</label></span>
						<input type="text"> 
					 </div>
					 <div>
						 <span>Email<label>*</label></span>
						 <input type="text"> 
					 </div>
					 <div class="clear"> </div>
					     <a class="news-letter" href="#">
						 <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i> </i>S'inscrire � la neswletter</label>
					   </a>
					 </div>
				     <div class="register-bottom-grid">
						    <h3>Pour vous authentifier</h3>
							 <div>
								<span>Password<label>*</label></span>
								<input type="text">
							 </div>
							 <div>
								<span>Retapez votre Password<label>*</label></span>
								<input type="text">
							 </div>
							 <div class="clear"> </div>
					 </div>
				</form>
				<div class="clear"> </div>
				<div class="register-but">
				   <form>
					   <input type="submit" value="M'inscrire">
					   <div class="clear"> </div>
				   </form>
				</div>
		   </div>
  <div class="clear"></div>
</div>
<!-- fin de la partie contenu -->

<?php
include("inc/bottom.php");
?>