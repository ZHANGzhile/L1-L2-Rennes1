<?php
include("inc/top.php");
?>

<!-- debut de la partie contenu -->
<div class="main">

		<div class="register">
			   <div class="col_1_of_list span_1_of_list login-left">
			  	 <h3>Nouveau membre</h3>
				 <p>En cr�ant un compte, vous pourrez cr�er des annonces</p>
				 <a class="acount-btn" href="sinscrire.php">Cr�er un compte</a>
			   </div>
			   <div class="col_1_of_list span_1_of_list login-right">
			  	<h3>D�ja membre ?</h3>
				<p>Si vous avez d�ja un compte, merci de vous connecter</p>
				<form>
				  <div>
					<span>Adresse email<label>*</label></span>
					<input type="text"> 
				  </div>
				  <div>
					<span>Mot de passe<label>*</label></span>
					<input type="text"> 
				  </div>
				  <a class="forgot" href="#">Mot de passe oubli�</a>
				  <input type="submit" value="Login">
			    </form>
			   </div>	
			   <div class="clearfix"> </div>
		
	</div>
  <div class="clear"></div>
</div><!-- fin de la partie contenu -->

<?php
include("inc/bottom.php");
?>