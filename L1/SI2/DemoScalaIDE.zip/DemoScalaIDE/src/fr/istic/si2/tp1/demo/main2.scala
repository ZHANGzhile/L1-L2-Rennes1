package fr.istic.si2.tp1.demo

object Main2 extends App{
  val hello: String="hello world"
  def justtry(bon: String): Unit = println(hello)
  
}