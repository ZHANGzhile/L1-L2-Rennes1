package fr.istic.si2.bonus1.sentinel

import fr.istic.si2.scribble._

object JeuSentinelle extends App {

  //Lancement du jeu
  bigbang(Sentinelle)

  //Pour le debug, vous pouvez tester vos images ici.
  //Par exemple:
  //  draw(Definitions.rotation(0,0),"0;0")
  //  draw(Definitions.rotation(0,1),"0;1")
}
