package fr.istic.si2.adnmatch

import fr.istic.si2.scribble._
import fr.istic.si2.adnmatch._

/**
 * Application ADNMatch version 3
 */
object ADNMAtchV3 extends App {

  // Lancement de l'interface graphique.
  bigbang(ADNMatchUniverse)

}