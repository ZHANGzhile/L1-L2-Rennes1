package fr.istic.si2.huffman

import Encodage._
import Decodage._
import Utils._

/**
 * Application principale V3 : avec transmission du code
 */
object HuffmanApp3 extends App {

  // TODO V3 - A vous de programmer l'application principale
  /*
  println(vers16Bits("r"))
  println(vers16Bits("c"))
  println(vers16Bits("d"))
  println(cherche16Bits(stringToListBit("000000001111111100000000"),16))
  println(encode("aabb"))
  println(lireDescription(stringToListBit(encode("abcdef"))))
  println(lireDescription(stringToListBit("10000000000110000100000000001100010")))
  println(decode("100000000001100001000000000011000100011"))*/
  
  def programme(): Unit = {
    val sh : String = lireFichier("fichiers/texte1.txt")
    val enco : String = encode(sh)
    val deco : String = decode(enco)
    ecrireFichier("fichiers/texte4.txt",deco)
    println("Regardez le fichier texte4.tet")
  }
  programme()
}