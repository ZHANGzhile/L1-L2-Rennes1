package fr.istic.si2.huffman

import Encodage._
import Decodage._
import ConstructionCode._
import Utils._

/**
 * Application principale V2 : avec construction du code
 */
object HuffmanApp2 extends App {

  /**
   * Une liste de couples caractère / fréquence d'apparition
   * à utiliser par l'application principale.
   */
  // TODO V2
  val lfreqs: List[(Char, Double)] = ('a',0.45)::('b',0.18)::('c',0.09)::('d',0.09)::('r',0.19)::Nil
  val s1: String = "ab"
  val h: List[Huffman] = initHuffman(lfreqs)
  val s2: String ="acbabcabbc"
  /*
  println(h)
  println(triSelonFreq(h))
  println(uneFusion(h))
  println(fusion(h))
  println("fusion")
  println(fusion(initHuffman(analyseFrequences(s2))))
  println("code Huffman")
  println(codeHuffman(lfreqs))
  println(s2.toList)
  println(analyseFrequences(s2))*/


  // TODO V2 - A vous de programmer l'application principale
  /**
   * Demontre le bon fonctionnement des fonctions ce qu'on a fait 
   */
  def programme(): Unit={
    val sh : String = lireFichier("fichiers/texte1.txt")
    val h : Huffman = codeHuffman(analyseFrequences(sh))
    val enhuffman: String = listBitToString(encode(sh,h))
    ecrireFichier("fichiers/texte3.txt",enhuffman)
    println("Regardez le fichier texte3.text")
  }
  programme()
  
}