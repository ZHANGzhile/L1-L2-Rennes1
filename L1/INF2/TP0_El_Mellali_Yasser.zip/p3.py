﻿# ASI TP (pour se faire un peu la main en Python)

# p3_cor.py

# Manipuler des tables de corresponsances (dictionnaires)

# comprendre l'existant et compléter



# efforcez vous de comprendre tout l'existant,
# et de compléter lez zones indiquées à compléter

#Fonction lire_int()
#lit une entrée (des  caractères chiffres) et rend un entier
def lire_int() :
    return int( input())
# fin Fonction lire_int



#Fonction lire_int_m()
#lit une entrée (des  caractères chiffres) et rend un entier
#il y a aun message d'invitation
def lire_int_m() :
    return int (input("Donner un entier :"))
# fin Fonction lire_int_m


#Fonction lire_int_m2(mess)
#lit une entrée (des  caractères chiffres) et rend un entier
#il y a aun message d'invitation passé en paramètre
def lire_int_m2(mess) :
 return int (input(mess))
# fin Fonction lire_int_m2

# déclaration et inirialisation d'un dictionnaire char x int
d1 ={'a':10,'w':1,'c':9,'z':10,'b':15,'u':4}

print(d1)
print("les cles",d1.keys())
l1cles=list(d1.keys())
print("une liste des cles",list(d1.keys()))

print("une liste(triee) des cles ",sorted(list(d1.keys())))



#procedure IncrementeSeuil(d dict, s int)
# incremente les valeurs >= s
def incrementeSeuil(d : dict, s :int) :
    for c in d.keys() :     #un parcours des clés
        if d[c] >= s :      # d[c] donne la valeur de la clé c (erreur si c n'est pas présente)
                            # pour tester la présence d'une clé : if c in d.keys() :
            d[c]=d[c]+1
#fin IncrementeSeuil

#test IncrementeSeuil

print("incrementeSeuil sur " ,d1)
print(d1)
incrementeSeuil(d1,10)
print(" --> ",d1)





#A PROGRAMMER ET TESTER
#Fonction cumulValTrie(d : dict) -> dict
#pre : d est un dictionnaire char x int
#post : rend un dictionnaire tel que :
# les clés sont les mêmes, les valeurs ont été cumulées (selon un ordre de clés triées)



# exemple

def cumulValTrie(d : dict ) :
    for c in d.keys() :
        x=
        while x<c :
            d[c]=d[c]+x
            x=
        #fin while
    #fin for
    
#fin cumulValTrie

#test cumulValTrie

print("cumulValTrie sur ")
print(d1)   # normalement {'a':11,'w':1,'c':9,'z':11,'b':16,'u':4}
d1r = cumulValTrie(d1)
print(" --> ",d1r) # normalement {'a':11,'b':27,'c':36,'u':40,'w':41,'z':52}











