print("bonjour !")
