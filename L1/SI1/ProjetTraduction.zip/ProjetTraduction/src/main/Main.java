package main;

import util.ACX;

public class Main {

	public static String [] traduire(String [] texte){
		//TODO
	}
	
	public static void main(String[] args) {
		
		//ACX.interfaceTraduction("traduire");
	}
}