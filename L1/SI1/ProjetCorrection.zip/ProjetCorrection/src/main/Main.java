package main;

import util.ACX;

public class Main {
	
	// A faire!
	public static boolean [] corriger(String[] texte, String[] dico){
	}
	
	public static boolean [] corrigerDico(String[] texte){
	}
	
	public static void main(String[] args){
		ACX.interfaceCorrection("corriger");
	}
}
