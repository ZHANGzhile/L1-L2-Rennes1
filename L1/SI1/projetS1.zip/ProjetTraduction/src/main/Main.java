package main;

import util.ACX;

public class Main {

    static String[] tra= ACX.lectureDico("lib/frenchEnglish.txt") ;
    static String[] cles;//tableau francais
    static String[] valeurs;//tableau anglais
    static String[] traracine= ACX.lectureDico("lib/racines.txt") ;
	static String[] justtry=ACX.mots("BAH bah");
	
	//pour initialiser le tableau francais et le tableau anglais
	public static void init(){
		cles = new String[tra.length/2];
		valeurs = new String[tra.length/2];
		int i1=0;
		int i2=0;
		for(int j=0;j<tra.length;) {
			cles[i1] = tra[j];
			i1++;
			j++;
			valeurs[i2] = tra[j];
			i2++;
			j++;
		}
	}
	
	//recherche dans un tableau de String non tri��
	public static int recherche(String cherche, String[] t){
		cherche=cherche.toLowerCase();
		for(int i=0;i<t.length;i++) {
			if(t[i].compareTo(cherche)==0) {
				return i;
			}
		}
		return -1;
	}
	
	//traduire des mots francais en mots anglais
	public static String [] traduire(String [] texte){
		//TODO
	    String[] textevaleur= new String[texte.length];
	    for(int i=0;i<texte.length;i++) {
	    	//if(recherche(texte[i],traracine) != -1) texte[i] = traracine[recherche(texte[i],traracine)-1];
	    	if(recherche(texte[i],cles) != -1) { 
	    		textevaleur[i] = valeurs[recherche(texte[i],cles)];
	    	}
	    	else textevaleur[i]=texte[i];
	    }
	    return textevaleur;
	}
	
	public static void main(String[] args) {
		init();
		//ACX.interfaceTraduction("traduire");
		System.out.println(recherche("bah",justtry));
		System.out.println(recherche("License",traracine));

	}
}