package tp9;

import java.util.concurrent.ThreadLocalRandom;
import outils.*;

public class TP9 {

	// Méthode fourni par le squelette
	public static int entierAleatoire(int a, int b){
		//Retourne un entier aléatoire entre a (inclus) et b (inclus)
		return ThreadLocalRandom.current().nextInt(a, b + 1);
	}

	// TODO écrivez ici vos fonctions
	public static void verifierPixel(Pixel p) {
		int[] t = new int[3];
		t[0]=p.r;
		t[1]=p.v;
		t[2]=p.b;
		for(int i=0;i<t.length;i++) {
			if(t[i]<0) t[i]=0;
			else if(t[i]>255) t[i]=255;
		}
		
	}
	
	public static BitMap simpleRectangle(int n, int m) {
		 BitMap img = new BitMap(n,m);
		 Pixel blanche = new Pixel(255,255,255);
		 Pixel noir = new Pixel(0,0,0);
		 for(int i=0;i<n;i++) {
			 for(int j=0;j<m;j++) {
				 img.set(i, j, blanche);
			 }
		 }
		 for(int h=10;h<=m-10;h++) {
				for(int l=10;l<=20;l++) {//Rectangle noir a gauche
					img.set(l, h, noir);
				}
				for(int l=n-20;l<n-10;l++) {//Rectangle noir a doroit
					 img.set(l, h, noir);
				}
		 }
		 for(int l=20;l<=n-20;l++) {
			 for(int h=10;h<20;h++) {//Rectangle noir au-dessus
				 img.set(l, h, noir);
			 }
			 for(int h=m-20;h<=m-10;h++) {//Rectangle noir ci-dessous
				 img.set(l, h, noir);
			 }
		 }
		 return img;
	}
    
	/*public static BitMap simpleCroix(int n, int m) {
		 BitMap img = new BitMap(n,m);
		 Pixel blanche = new Pixel(255,255,255);
		 Pixel noir = new Pixel(0,0,0);
		 for(int i=0; i<m; i++) {
	            for(int i2=0;i2<n;i2++) {
	                if((i>=10 && i<=m-10 && i2>=10 && i2<=n-10) && !(i>=20 && i<=m-20 && i2>=20 && i2<=n-20)) {
	                    img.set(i, i2, noir);
	                }else {
	                    img.set(i, i2, blanc);
	                }
	            }
	        }
	}*/
    public static BitMap composanteRouge(BitMap img) {
		
		BitMap res=new BitMap(img.largeur(),img.hauteur());
		
		 for(int i=0;i<img.largeur();i++) {   //rendre touts les pixels blanche
			 
			 for(int j=0;j<img.hauteur();j++) {
				 
				 Pixel p = img.get(i,j); 
				 
				 p.r=255;
				 
				 res.set(i,j, p);
				 
			 }
			 
		 }
		return res;
		
	}
	
	public static BitMap composanteVerte(BitMap img) {
		int l = img.largeur(); 
		int h = img.hauteur();
		BitMap ver = new BitMap(l,h);
		for(int i=0;i<l;i++) {
			for(int j=0;j<h;j++) {
				Pixel p=img.get(i, j);
				p.v=255;
				ver.set(i, j, p);
			}
		}
		return ver;
	}
	
	public static BitMap composanteBleue(BitMap img) {
		int l = img.largeur(); 
		int h = img.hauteur();
		BitMap ble = new BitMap(l,h);
		for(int i=0;i<l;i++) {
			for(int j=0;j<h;j++) {
				Pixel p=img.get(i, j);
				p.b=255;
				ble.set(i, j, p);
			}
		}
		return ble;
	}
	
	public static BitMap inverser(BitMap img) {
		int l = img.largeur(); 
		int h = img.hauteur();
        BitMap newimg=new BitMap(l,h);
        for(int i=0;i<img.largeur();i++) {   //
             for(int j=0;j<img.hauteur();j++) {
                 Pixel p = img.get(i,j); 
                 p.r=255-p.r;
                 p.b=255-p.b;
                 p.v=255-p.v;
                 verifierPixel(p);
                 newimg.set(i,j, p);
             }
         }
         return newimg;
    }
	
	public static BitMap bruit(BitMap img,int m) {
		int l =img.largeur();
		int h =img.hauteur();
		BitMap newimg = new BitMap(l,h);
		for(int i=0;i<l;i++) {
			for(int j=0;j<h;j++) {
				Pixel p=img.get(i,j);
				p.r=p.r-entierAleatoire(-m,m);
				p.v=p.v-entierAleatoire(-m,m);
				p.b=p.b-entierAleatoire(-m,m);
				verifierPixel(p);
				newimg.set(i, j, p);
			}
		}
		return newimg;
	}
	
	public static BitMap filtreMonochrome(BitMap img) {
		int l =img.largeur();
		int h =img.hauteur();
		BitMap newimg = new BitMap(l,h);
		for(int i=0;i<l;i++) {
			for(int j=0;j<h;j++) {
				Pixel p=img.get(i,j);
				verifierPixel(p);
				if((p.r+p.v+p.b)/3 < 128) {
					p.r=0;
					p.v=0;
					p.b=0;
				}
				else {
					p.r=255;
					p.v=255;
					p.b=255;
				}
				newimg.set(i, j, p);
			}
		}
		return newimg;
	}
	
	public static BitMap filtreGris(BitMap img,boolean choix) {
		int l =img.largeur();
		int h =img.hauteur();
		double moyenne;
		BitMap newimg = new BitMap(l,h);
		for(int i=0;i<l;i++) {
			for(int j=0;j<h;j++) {
				Pixel p=img.get(i,j);
				if(choix) moyenne=(p.r+p.v+p.b)/3;
				else moyenne=p.r*0.2125 + p.v*0.7154+p.b*0.0721;
				p.r=(int)moyenne;
				p.v=(int)moyenne;
				p.b=(int)moyenne;
				verifierPixel(p);
				newimg.set(i, j, p);
			}
		}
		return newimg;
	}
	
	public static  Pixel calculSepia(Pixel p) {
		Pixel p2 = new Pixel (p.r,p.v,p.b);
		p2.r=(int)(0.393*p.r + 0.769*p.v + 0.189*p.b);
		p2.v=(int)(0.349*p.r + 0.686*p.v + 0.168*p.b);
		p2.b=(int)(0.272*p.r + 0.534*p.v + 0.131*p.b);
		return p2;
	}
	
	public static BitMap filtreSepia(BitMap img) {
		int l =img.largeur();
		int h =img.hauteur();
		BitMap newimg = new BitMap(l,h);
		for(int i=0;i<l;i++) {
			for(int j=0;j<h;j++) {
				Pixel p=img.get(i,j);
				p=calculSepia(p);
				verifierPixel(p);
				newimg.set(i,j,p);
			}
		}
		return newimg;
	}
	
	
	public static BitMap posteriser(BitMap img, int n) {
		int l =img.largeur();
		int h =img.hauteur();
		BitMap newimg = new BitMap(l,h);
		for(int i=0;i<l;i++) {
			for(int j=0;j<h;j++) {
				Pixel p =img.get(i,j);
				if(p.r % n >(n/2)) p.r=((p.r/n)+1)*n;
				else p.r = (p.r/n)*n;
				if(p.v % n >(n/2)) p.v=((p.v/n)+1)*n;
				else p.v = (p.v/n)*n;
				if(p.b % n >(n/2)) p.b=((p.b/n)+1)*n;
				else p.b = (p.b/n)*n;
				verifierPixel(p);
				newimg.set(i,j,p);
			}
		}
		return newimg;
	}
	public static void main(String[] args) {

		System.out.println("Début du TP 9");

		// Exercice 1
		
		//BitMap rectangle = simpleRectangle(100, 100);
		//BitMap.enregistreBitMap(rectangle, "simpleRectangle");
		

		// Exercice 2
		/*
		BitMap croix = simpleCroix(100, 100);
		BitMap.enregistreBitMap(croix, "simpleCroix");
		*/

		// Lit l'image tiger.bmp dans le dossier principal du projet (au dessus du dossier src/ qui contient TP9.java)
		BitMap img = BitMap.aPartirDe("tiger.bmp");
		
		
		

		// Exercice 3
		
		//BitMap.enregistreBitMap(composanteRouge(img),"tiger_rouge");
		//BitMap.enregistreBitMap(composanteVerte(img),"tiger_vert");
		//BitMap.enregistreBitMap(composanteBleue(img),"tiger_bleu");
		

		// Exercice 4
		
		//BitMap.enregistreBitMap(inverser(img),"tiger_inverse");
		

		// Exercice 5
		
		//BitMap.enregistreBitMap(bruit(img, 128),"tiger_bruit128");
		//BitMap.enregistreBitMap(bruit(img, 64),"tiger_bruit128");
		

		// Exercice 6
		
		//BitMap.enregistreBitMap(filtreMonochrome(img),"tiger_mono");
		

		
		//BitMap.enregistreBitMap(filtreGris(img, false),"tiger_gris_pasrealiste");
		//BitMap.enregistreBitMap(filtreGris(img, true),"tiger_gris_realiste");
		

		
		BitMap.enregistreBitMap(filtreSepia(img),"tiger_sepia");
		

		// Exercice 7
		/*
		BitMap.enregistreBitMap(posteriser(img, 32),"tiger_post32");
		BitMap.enregistreBitMap(posteriser(img, 64),"tiger_post64");
		BitMap.enregistreBitMap(posteriser(img, 128),"tiger_post128");
		*/

		// Exercice 8
		/*
		BitMap.enregistreBitMap(flou(img), "tiger_flou");
		BitMap.enregistreBitMap(flou(flou(img)), "tiger_flou_flou");
		*/

		System.out.println("Fin du TP 9");
	}

}








