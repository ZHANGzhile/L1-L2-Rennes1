package tp1;

public class Exe6 {
	//Affichage dans l'ordre croissant
	public static void tryfgdf(String s){
		char c =s.charAt(s.length()-1);
		System.out.println((int)c);
	}
	
	 public static boolean verifierFormat(String s) { // ATTENTION, vous devez modifier la signature de cette fonction
	        char a =s.charAt(0); //Le premier caract��re
	        char c =s.charAt(3); //Le dernier caract��re
	        char m1 = s.charAt(1); //Le prmeier chiffre du millieu
	        char m2 = s.charAt(2); //Le deuxieme chiffre du millieu
	        return(
	            (a=='r' || a=='d') && 
	            ((c>='a' && c<='z') || (c>='A' && c<='Z')) && 
	            (m1 >= '0' && m1 <= '9' && m2 >= '0' && m2 <= '9') &&
	            (s.length == 4)
	        );
	    }
	
	public static int[] conversionCoordonnees(String input) { // ATTENTION, vous devez modifier la signature de cette fonction
		int[] t= new int[3];
		if(verifierFormat(input)) {
			int ligne =(input.charAt(1)-(int)'0')*10+input.charAt(2)-(int)'0';
			//t[0] = Integer.parseInt("input.charAt(1)+input.charAt(2)");
			t[0] = ligne;
			if(input.charAt(3) >='A' && input.charAt(3) <='Z') t[1] = (int)input.charAt(3) - 65;
			else t[1] = (int)input.charAt(3) - 97 + 26;
			if(input.charAt(0) == 'd') t[2] = 0;
			else t[2] = 1;
		}
		return t;
	}
	
	public static void affiche(int[] t) {
		for(int i=0;i<t.length;i++) {
			System.out.print(t[i]+" ");
		}System.out.println();
	}
	
	public static void main(String[] args) {
        String s ="gamme";
        String s1="d03a";
	    tryfgdf(s);
	    System.out.println(verifierFormat(s1));
	    affiche(conversionCoordonnees(s1));
	    
	}
}
