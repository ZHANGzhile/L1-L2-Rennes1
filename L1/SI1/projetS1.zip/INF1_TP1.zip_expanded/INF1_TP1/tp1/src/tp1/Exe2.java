package tp1;
import java.util.Scanner;

public class Exe2 {
	//Sasie et opérations de base

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);





		sc.close();
	}
}
