package tp1;

public class Exe5 {
	//Parité d'une somme

	public static void main(String[] args) {

	}
}
