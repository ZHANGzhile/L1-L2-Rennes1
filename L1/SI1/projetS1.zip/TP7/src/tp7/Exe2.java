package tp7;

public class Exe2 {
	
	// ��crire une fonction pour v��rifier si les sommes des ��l��ments de chaque ligne sont ��gales
	public static int sommeLigne(int[][] tab ,int i){
		int somme = 0;
		if (i >= tab.length) {
			return 0 ;
		}
		for (int j = 0; j < tab[i].length ;j++ ) {
			somme = somme + tab[i][j];
		}return somme;
	}

	public static boolean verifierLignes(int[][] t){
		for (int i = 0; i < t.length-1;i++ ) {
			if (sommeLigne(t,i) != sommeLigne(t,i+1)) {
				return false;
			}
		}return true;
	}
	// ��crire une fonction pour v��rifier si les sommes des ��l��ments de chaque colonne sont ��gales
	public static int sommeColonne(int[][]tab , int i){
    	int somme = 0;
    	for (int x = 0; x < tab.length ;x++ ) {   
    	    if (i>= tab[x].length) {
    	    	somme = somme ;    	
    	    }else{	    
    	    	somme = somme + tab[x][i];
    	    } 
    	}return somme;
    }

    public static boolean verifierColonne(int[][] t){
    	for (int i = 0; i < t[0].length-1;i++ ) {
    		if (sommeColonne(t,i) != sommeColonne(t,i+1)) {
    			return false;
    		}
    	}return true ;
    }
	// ��crire une fonction pour v��rifier si un tableau d'entiers est magique
    public static boolean estMagique(int[][] t){
    	if (verifierLignes(t) && verifierColonne(t)) {
    		return true;
    	}else return false;
    }
    
	public static void main(String[] args) {
		int[][] rectangle = {{1, 12, 20, 8, 17, 6, 13}, 
	             			 {14, 2, 10, 21, 9, 16, 5}, 
	             			 {18, 19, 3, 4, 7, 11, 15}};
		System.out.println(verifierLignes(rectangle));
		System.out.println(verifierColonne(rectangle));
		System.out.println(estMagique(rectangle));
	}
}
