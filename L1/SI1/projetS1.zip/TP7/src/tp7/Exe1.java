package tp7;

public class Exe1 {
	
	// ��crire une fonction qui affiche le tableau d'entr��e
	public static void afficheTab2D(int[][] t) {
		for(int i = 0; i < t.length; i++) {
			for(int j = 0; j < t[i].length ; j++) {
				System.out.print(t[i][j]+" ");
			}System.out.println();
		}
	}
	
	public static void main(String[] args) {
		int[][] rectangle = {{1, 12, 20, 8, 17, 6, 13}, 
    			 			 {14, 2, 10, 21, 9, 16, 5}, 
    			 			 {18, 19, 3, 4, 7, 11, 15}};
		afficheTab2D(rectangle);

	}
	
}