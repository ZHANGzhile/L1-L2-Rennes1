package tp7;

public class Exe4 {
	public static void afficheTab2D(int[][] t) {
		for(int i = 0; i < t.length; i++) {
			for(int j = 0; j < t[i].length ; j++) {
				System.out.print(t[i][j]+" ");
			}System.out.println();
		}
	}
	
	// ��crire une fonction qui renvoie la somme de deux tableaux

	public static int[][] sommeRectangles(int[][] t1 ,int[][] t2){
		int[][] t = new int[t1.length][t1[0].length];
		for (int i =0; i<t.length ;i++ ) {
			for (int j =0;j<t[0].length ;j++ ) {
				t[i][j] = t1[i][j]+t2[i][j];
			}
		}return t;
	}
	
	// ��crire une fonction qui renvoie la sym��trie horizontale du tableau d'entr��e
	public static int[][] symetrieHorizontale(int[][] t){
		int[][] t2 = new int[t.length][t[0].length];
		for (int i = 0;i<t.length;i++ ) {
			for (int j = 0;j<t[0].length;j++ ) {
				t2[i][j] = t[t.length-1-i][j];
			}
		}return t2;
	}
	
	// ��crire une fonction qui renvoie la sym��trie verticale du tableau d'entr��e
	public static int[][] symetrieVerticale(int[][] t){
		int[][] t2 = new int[t.length][t[0].length];
		for (int i = 0;i<t.length;i++ ) {
			for (int j = 0;j<t[0].length;j++ ) {
				t2[i][j] = t[i][t[0].length-1-j];
			}
		}return t2;
	}
	
	// ��crire une fonction qui renvoie la transposition du tableau d'entr��e
	public static int[][] transpose(int[][] t){
		int[][] t2 = new int[t[0].length][t.length];
		for (int i = 0;i<t2.length;i++ ) {
			for (int j = 0;j<t2[0].length;j++ ) {
				t2[i][j] = t[j][i];
			}
		}return t2;
	}
	
	// ��crire une fonction qui renvoie la rotation du tableau d'entr��e
	public static int[][] rotation(int[][] t){
		int[][] t2 = transpose(t);
		int[][] t3 = symetrieHorizontale(t2);
		return t3;
	}
	
	public static void main(String[] args) {
		int[][] rectangle = {{1, 12, 20, 8, 17, 6, 13}, 
	             			 {14, 2, 10, 21, 9, 16, 5}, 
	             			 {18, 19, 3, 4, 7, 11, 15}};
		afficheTab2D(sommeRectangles(rectangle,rectangle));
		System.out.println("**************************************");
		afficheTab2D(symetrieHorizontale(rectangle));
		System.out.println("**************************************");
		afficheTab2D(symetrieVerticale(rectangle));
		System.out.println("**************************************");
		afficheTab2D(transpose(rectangle));
		System.out.println("**************************************");
		afficheTab2D(rotation(rectangle));
	}
}