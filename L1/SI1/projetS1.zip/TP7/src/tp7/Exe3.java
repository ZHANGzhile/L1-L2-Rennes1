package tp7;

public class Exe3 {
	
	// ��crire une fonction pour v��rifier si un tableau est normal
	public static boolean normal(int[][] t , int a){
	       for (int i = 0; i < t.length ; i++ ) {
	    		    for (int j = 0; j<t[0].length ;j++ ) {
	    			    if (t[i][j] == a) {
	    				    return true;
	    			    }
	    		    }
	    		}return false;
	    }

	    public static boolean estNormal(int[][] t){
	    	for (int z = 1;z <= t.length*t[0].length;z++ ) {
	    		boolean boo = normal(t,z);
	    		if (!boo) {
	    			return false;
	    		}
	    	}return true;
	    }
	    
	public static void main(String[] args) {
		int[][] rectangle = {{1, 12, 20, 8, 17, 6, 13}, 
	             			 {14, 2, 10, 21, 9, 16, 5}, 
	             			 {18, 19, 3, 4, 7, 11, 15}};
		System.out.println(estNormal(rectangle));
	}
}
