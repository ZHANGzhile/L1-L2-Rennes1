package main;

import static org.junit.Assert.*;
import org.junit.Test;

public class MainTest {
	// Pour tester la recherche dichotomique on a besoin de tableaux tri��
	int[] t= {-8,2,4,10};
	int[] t1 = {};
	int[] t2 ={1};
	int[] t3 ={1,3};
	int[] t4 = {1,2,3,5,9,10,20,25};

	
	@Test
	public void test1(){
	assertEquals(0,Main.rechercheDicho(-8,t));
    }
	
	@Test
	public void test2(){
	assertEquals(-1,Main.rechercheDicho(-8,t1));
	}
	
	@Test
	public void test3(){
	assertEquals(0,Main.rechercheDicho(1,t2));
	}
	
	@Test
	public void test4(){
	assertEquals(1,Main.rechercheDicho(3,t3));
	}
	
	@Test
	public void test5(){
	assertEquals(6,Main.rechercheDicho(20,t4));
	}
}	
	
