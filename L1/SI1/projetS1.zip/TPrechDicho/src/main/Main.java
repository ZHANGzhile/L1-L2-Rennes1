package main;

import util.ACX;


public class Main {
	public static int rechercheDicho(int cherche, int[] t) {
		int debut=0;
		int fin=t.length-1;
		int milieu= (debut+fin)/2;
		while(fin - debut >= 0 ) {
			milieu = (debut + fin)/2;
			if(t[debut] == cherche) return debut;
			if(t[fin] == cherche) return fin;
			if(t[milieu] == cherche) return milieu;
			else if(t[milieu] > cherche) fin = milieu-1;
			else debut = milieu+1;
		}return -1;
	}
	
	public static int recherche(int cherche, int[] t){
		// A FAIRE!
		for(int i = 0 ; i < t.length ; i++) {
			if(t[i] == cherche) {
				return i;
			}
		}
		return -1;
	}
	
	public static int recherche(String cherche, String[] t) {
		for(int i =0;i<t.length;i++) {
			int j = cherche.compareTo(t[i]);
			if(j == 0) {
				return i;
			}
		}return -1;
	}
	
	public static int rechercheDicho(String cherche, String[] t) {
		int debut = 0;
		int fin = t.length-1;
		int milieu = (debut + fin)/2;
		while(fin - debut >= 0) {
			milieu = (debut+fin)/2;
			if(t[debut].compareTo(cherche) == 0) return debut;
			if(t[fin].compareTo(cherche) == 0) return fin;
			if(t[milieu].compareTo(cherche) ==0) return milieu;
			else if(cherche.compareTo(t[milieu]) < 0) fin = milieu -1;
			else debut = milieu +1;
		}return -1;
	}
	
	public static String[] tri(String[] t) {
		String a ="";
		for (int i =0;i<t.length-1;i++ ) {
      	    for (int j = i+1 ;j<t.length ;j++ ) {
      	    	if (t[i].compareTo(t[j]) > 0) {
      	    		a = t[i];
      	    		t[i]=t[j];
      	    		t[j]=a;
      	    	}
      	    }
		}
		return t;
	}
	
	public static void main(String[] args) {
		int[] t = {};
		int[] t1 ={1};
		int[] t2 ={1,3};
		int[] t3 ={2,4,8,10};
		int[] t4 = {1,2,3,5,9,10,20,25};
		String s1 = "abc";
		String[] t5= {"abc","def","efg","jed"};
		System.out.println(rechercheDicho(1,t));
		System.out.println(rechercheDicho(1,t1));
		System.out.println(rechercheDicho(3,t2));
		System.out.println(rechercheDicho(4,t3));
		System.out.println(rechercheDicho(20,t4));
		System.out.println("**************************");
		System.out.println(recherche(s1,t5));
		System.out.println(rechercheDicho(s1,t5));
		
		String[] dico =ACX.lectureDico("lib/dico.txt");
		String[] ger = ACX.lectureTexte("lib/germinalExtrait.txt");
		for(int i =0; i<ger.length;i++) {
			if(recherche(ger[i],dico) == -1) System.out.print(ger[i]+"*"+" ");
			else System.out.print(ger[i]+" ");
		}
		
		
		
		
		ACX.erreur("Le minimum n'est pas d��fini sur le tableau vide.");
		
		
		
		//String[] fonctions= {"recherche","rechercheDicho"}; 
		//ACX.tracerRecherche(fonctions);
	}
}


