package main;

import util.ACX;


public class Main {
	//TODO
	public static void tribulle(int [] t){
		for (int i =0;i<t.length-1;i++ ) {
      	    for (int j = 0 ;j<t.length-i-1;j++ ) {
      	    	if (t[j]>t[j+1]) {
      	    		int temp = t[j+1];
      	    		t[j+1]=t[j];
      	    		t[j]=temp;
      	    	}
      	    }
        }
	}
	
	public static void swap( int[] t,int i,int j) { 
	    int tmp = t[i];
	    t[i]=t[j];
	    t[j]=tmp;
	}
	    
	public static void triselection(int[] t) {
	    for(int i=0;i<t.length;i++) {
	        int min=i;
	        for(int j=i+1;j<t.length;j++) {
	            if(t[j]<t[min]) {
	                min=j;
	            }
	        }
	        swap(t,i,min);
	    }
	}
	
	public static void triInsertion(int[] tab) {
	    for(int i = 1; i < tab.length; i++) {
	        int n = tab[i];
	        int j = i;
	        while (j > 0 && tab[j - 1] > n) {
	            tab[j] = tab[j - 1];
	            j = j - 1;
	        }
	        tab[j] = n;
	    }
	}
	
	public static void affiche(String[] t) {
		for(int i=0;i<t.length;i++) {
			System.out.print(t[i]+" ");
		}System.out.println();
	}
	
	static boolean estTrie(int[] t) {
		for(int i=0;i<t.length-1;i++) {
			if(t[i]>t[i+1]) return false;
		}
		return true;
	}
	
	public static int[] sousTableau(int[] tab, int i, int j){
		int[] tab2 = new int[(j-i)+1];
		for(int z = 0 ;z <= j-i ; z++) {
			tab2[z]= tab[z+i];			
		}
		return tab2;  
	}
	/*
	public static void triFusion(String[] t, int gauche, int droite){
	    if(gauche < droite){
	    	int milieu = (gauche+droite)/2;
	        //triFusion(t, gauche,milieu); /*triFusion(t1)*/
	        //triFusion(t, milieu+1,droite); /*triFusion(t1)*/
	        //fusion(t,gauche,milieu,droite); /*fusion(t1_, t2_)*/
	    //}
	//}
	
	/*
    public static void fusion(int[] t, int debut, int milieu, int fin) {
    	int[] temp = new int[fin-debut+1];
        int i= debut;
        int j = milieu+1;
        int k=0;
        while (i<=milieu && j<=fin) {//Remplisser les ��l��ments plus petits dans les sous-tableaux en temp
            if(t[i]<=t[j]) {
                temp[k]=t[i];
                i++;
                k++;
            }
            else {
                temp[k]=t[j];
                j++;
                k++;
            }
        }
        while (i<=milieu){//Remplisser les ��l��ments restants sur la gauche en temp
            temp[k]=t[i];
            i++;
            k++;
        }
        while (j<=fin){//Remplissez les ��l��ments restants sur la droite en temp
            temp[k]=t[j];
            j++;
            k++;
        }
        for(int x=0;x+debut<temp.length;x++){
        	t[debut++] = temp[x];
        }
    }*/
    /*
triFusion(t,0,7)
triFusion(t,0,3)
triFusion(t,0,1)
triFusion(t,0,0)
triFusion(t,1,1)
fusion(t,0,0,1)
triFusion(t,2,3)
triFusion(t,2,2)
triFusion(t,3,3)
fusion(t,2,2,3)
fusion(t,0,1,3)
triFusion(t,4,7)
triFusion(t,4,5)
triFusion(t,4,4)
triFusion(t,5,5)
fusion(t,4,4,5)
triFusion(t,6,7)
triFusion(t,6,6)
triFusion(t,7,7)
fusion(t,6,6,7)
fusion(t,4,5,7)
fusion(t,0,3,7)
     
     */
	public static void triFusion(String[] t, int gauche, int droite){
	    if(gauche < droite){
	    	int milieu = (gauche+droite)/2;
	        triFusion(t, gauche,milieu); /*triFusion(t1) Recurse(r��cursif) sous-tableau a gauche */
	        triFusion(t, milieu+1,droite); /*triFusion(t1) Recurse(r��cursif) sous-tableau a droite*/
	        fusion(t,gauche,milieu,droite); /*fusion(t1_, t2_)*/
	    }
	}
	public static void fusion(String[] dico, int gauche, int milieu, int droite) { 
		 int i = gauche; 
		 int j = milieu+1; 
		 int k = 0; 
		 String[] temp = new String[droite - gauche + 1]; //Cr��er un tableau temporaire pour stocker le tableau temporairement tri�� 
		 while (i <= milieu && j <= droite) { //c.a.d devoir moins que la longueur des deux sous-tableaux
		     // Prenez le plus petit des deux sous-tableaux dans le tableau temporaire
		     if (dico[i].compareTo(dico[j])>=0) { //si l'element dans le sous-tableau a gauche est plus petit ou egale que l'element dans le droite sous-tableau
		         temp[k] = dico[j]; 
		         k++;
		         j++;
		     }else { 
		         temp[k] = dico[i];
		         k++;
		         i++;
		     } 
		 } 
		 //Les parties restantes sont plac��es dans le tableau temporaire par leur ordre(deja tri dans le sous-tableau)
		 //En fait, ces deux boucles while n'ex��cuteront qu'une seule d'entre elles 
		 //Parce que nous avons compar�� tous les ��l��ments de l'un des sous-tableaux avec certains ��l��ments de l'autre sous-tableau et deja les remplis dans le tableau temporaire
		 while (i <= milieu) { //les restes(c.a.d plus grandes) elements sont dans le sous-tableau a gauche
		     temp[k++] = dico[i++]; 
		 } 
		 while (j <= droite) { //les restes(c.a.d plus grandes) elements sont dans le sous-tableau a droite
		     temp[k++] = dico[j++]; 
		 } 
		 // Copiez les elements du tableau temporaire dans le tableau d'origine
		 for(int x=0;x<temp.length;x++){
	         dico[gauche++] = temp[x];
		 } 
	}
	// f(x)= x^2/100000
	public static int refQuadratique(int x){return (int) Math.pow(x,2)/100000;}

	// f(x)= x*log(x)/3000
	public static int refLinearithmique(int x){return (int) (x*Math.log(x)/3000);}


	public static void main(String[] args) {
		int[] t = {};
		int[] t1 ={1};
		int[] t2 ={3,1};
		int[] t3= {2,1,3};
		int[] t4= {7,49,30,56,25,1,88,99};
		String[] t5 = {"abc","abcd","a","b","gh"};
		//tribulle(t);tribulle(t1);tribulle(t2);tribulle(t3);
		triFusion(t5,0,t5.length-1);
		affiche(t5);
		//affiche(t);affiche(t1);affiche(t2);affiche(t3);
		//String[] fun= {"tri"};
		//String[] ref= {"refQuadratique","refLinearithmique"};
		//ACX.tracerTriInt(fun,ref);		
	}

}
