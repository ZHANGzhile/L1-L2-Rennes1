package main;

import static org.junit.Assert.*;
import org.junit.Test;

public class MainTest {
	// Pour tester la recherche dichotomique on a besoin de tableaux triés
	int[] t= {-8,2,4,10};
	
//	@Test
//	public void test1(){
//		assertEquals(0,Main.rechercheDicho(-8,t));
//	}
}	
	
