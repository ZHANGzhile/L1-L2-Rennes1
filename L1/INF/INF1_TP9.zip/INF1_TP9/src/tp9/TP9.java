package tp9;

import java.util.concurrent.ThreadLocalRandom;
import outils.*;

public class TP9 {

	// Méthode fourni par le squelette
	public static int entierAleatoire(int a, int b){
		//Retourne un entier aléatoire entre a (inclus) et b (inclus)
		return ThreadLocalRandom.current().nextInt(a, b + 1);
	}

	// TODO écrivez ici vos fonctions

	public static void main(String[] args) {

		System.out.println("Début du TP 9");

		// Exercice 1
		/*
		BitMap rectangle = simpleRectangle(100, 100);
		BitMap.enregistreBitMap(rectangle, "simpleRectangle");
		*/

		// Exercice 2
		/*
		BitMap croix = simpleCroix(100, 100);
		BitMap.enregistreBitMap(croix, "simpleCroix");
		*/

		// Lit l'image tiger.bmp dans le dossier principal du projet (au dessus du dossier src/ qui contient TP9.java)
		BitMap img = BitMap.aPartirDe("tiger.bmp");

		// Exercice 3
		/*
		BitMap.enregistreBitMap(composanteRouge(img),"tiger_rouge");
		BitMap.enregistreBitMap(composanteVerte(img),"tiger_vert");
		BitMap.enregistreBitMap(composanteBleue(img),"tiger_bleu");
		*/

		// Exercice 4
		/*
		BitMap.enregistreBitMap(inverser(img),"tiger_inverse");
		*/

		// Exercice 5
		/*
		BitMap.enregistreBitMap(bruit(img, 128),"tiger_bruit128");
		BitMap.enregistreBitMap(bruit(img, 128),"tiger_bruit128");
		*/

		// Exercice 6
		/*
		BitMap.enregistreBitMap(filtreMonochrome(img),"tiger_mono");
		*/

		/*
		BitMap.enregistreBitMap(filtreGris(img, false),"tiger_gris_pasrealiste");
		BitMap.enregistreBitMap(filtreGris(img, true),"tiger_gris_realiste");
		*/

		/*
		BitMap.enregistreBitMap(filtreSepia(img),"tiger_sepia");
		*/

		// Exercice 7
		/*
		BitMap.enregistreBitMap(posteriser(img, 32),"tiger_post32");
		BitMap.enregistreBitMap(posteriser(img, 64),"tiger_post64");
		BitMap.enregistreBitMap(posteriser(img, 128),"tiger_post128");
		*/

		// Exercice 8
		/*
		BitMap.enregistreBitMap(flou(img), "tiger_flou");
		BitMap.enregistreBitMap(flou(flou(img)), "tiger_flou_flou");
		*/

		System.out.println("Fin du TP 9");
	}

}








