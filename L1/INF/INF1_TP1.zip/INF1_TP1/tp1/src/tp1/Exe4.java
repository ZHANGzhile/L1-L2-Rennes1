package tp1;

public class Exe4 {
	//Conversion secondes

	public static void main(String[] args) {

	}
}
