package tp1;

public class Exe6 {
	//Affichage dans l'ordre croissant

	public static void main(String[] args) {

	}
}
