package tp7;

public class Exe4 {
	
	// Écrire une fonction qui renvoie la somme de deux tableaux
	
	// Écrire une fonction qui renvoie la symétrie horizontale du tableau d'entrée
	
	// Écrire une fonction qui renvoie la symétrie verticale du tableau d'entrée
	
	// Écrire une fonction qui renvoie la transposition du tableau d'entrée
	
	// Écrire une fonction qui renvoie la rotation du tableau d'entrée
	
	public static void main(String[] args) {
		int[][] rectangle = {{1, 12, 20, 8, 17, 6, 13}, 
	             			 {14, 2, 10, 21, 9, 16, 5}, 
	             			 {18, 19, 3, 4, 7, 11, 15}};
	}
}