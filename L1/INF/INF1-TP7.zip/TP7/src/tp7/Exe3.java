package tp7;

public class Exe3 {
	
	// Écrire une fonction pour vérifier si un tableau est normal
	
	public static void main(String[] args) {
		int[][] rectangle = {{1, 12, 20, 8, 17, 6, 13}, 
	             			 {14, 2, 10, 21, 9, 16, 5}, 
	             			 {18, 19, 3, 4, 7, 11, 15}};
	}
}
