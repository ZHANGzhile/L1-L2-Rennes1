package tp7;

public class Exe1 {
	
	// Écrire une fonction qui affiche le tableau d'entrée
	
	public static void main(String[] args) {
		int[][] rectangle = {{1, 12, 20, 8, 17, 6, 13}, 
    			 			 {14, 2, 10, 21, 9, 16, 5}, 
    			 			 {18, 19, 3, 4, 7, 11, 15}};

	}
	
}